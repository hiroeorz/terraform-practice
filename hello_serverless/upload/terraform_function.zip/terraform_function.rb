def lambda_handler(event:, context:)
  {statusCode: 200, context: "hello terraform lambda!"}
end
